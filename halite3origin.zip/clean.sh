rm *.log
rm replays/*
