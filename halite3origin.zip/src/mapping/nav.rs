extern crate rand;

use std::collections::HashSet;
use rand::Rng;
use rand::distributions::{Distribution,Uniform};


use std::time::{Duration,Instant};    
use mapping::{mapraw, field};
use policy::task;
use metric::norm;
use hlt::{log,constants};

pub enum Dir {
    YPos,
    YNeg,
    XPos,
    XNeg,
}

fn get_feasible_route( log: & mut log::Log, map_units: &mapraw::UnitMap, resource_assign: & mut task::ResourceAssign, done: & mut HashSet<i32>, pos: (i32,i32), dest: (i32,i32) ) -> Option<(i32,i32)> {
    let mut dy = get_closest_dir( pos.0, dest.0, map_units.dim.0 );
    let mut dx = get_closest_dir( pos.1, dest.1, map_units.dim.1 );

    log.log(&format!("feasible route: [{}][{}] -> [{}][{}]", pos.0, pos.1, dest.0, dest.1 ));
    
    let l = norm::norm_l1( dy, dx );
    if l <= 3 {
        let range = Uniform::from(0..100);
        let mut rng = rand::thread_rng();
        let v = range.sample( & mut rng );
        if v >= 80 || l == 0 {
            match map_units.get( pos.0, pos.1 ) {
                mapraw::Unit::Ship{ player, id, halite } => {
                    let id2 = id as i32;
                    match resource_assign.stat.get_mut( &id2 ) {
                        Some(g) => {
                            match g.task {
                                task::Task::Collect( dest, _ ) => {
                                    g.task = task::Task::Collect(dest,Some(2));
                                    log.log(&format!("task becomes idle"));
                                    return None
                                },
                                _ => {},
                            };
                        },
                        _ => {},
                    }
                },
                _ => {},
            }
            return None
        }
    }
    if dy.abs() > 0 {
        dy = dy/dy.abs();
    }
    if dx.abs() > 0 {
        dx = dx/dx.abs();
    }

    log.log(&format!("feasible route: dy,dx: [{}][{}]", dy,dx ));
    
    let cell_y = map_units.get( pos.0 + dy, pos.1 );
    let cell_x = map_units.get( pos.0, pos.1 + dx );
    match cell_y {
        x @ mapraw::Unit::Ship{..} => {
        },
        _ => {
            return Some( ((pos.0 + dy)%map_units.dim.0, pos.1) )
        },
    }
    match cell_x {
        x @ mapraw::Unit::Ship {.. } => {
        },
        _ => {
            return Some( (pos.0, (pos.1 + dx)%map_units.dim.1 ) )
        },
    }

    //random
    let mut sel = vec![];
    for i in -1..=1{
        let cell = map_units.get( pos.0 + i, pos.1 );
        match cell {
            mapraw::Unit::None => {
                sel.push( Some( ((pos.0+i)%map_units.dim.0,pos.1) ) );
            },
            _ => {},
        }
    }
    for i in -1..=1{
        let cell = map_units.get( pos.0, (pos.1 + i) );
        match cell {
            mapraw::Unit::None => {
                sel.push( Some( (pos.0, (pos.1 + i)%map_units.dim.1) ) );
            },
            _ => {},
        }
    }

    if sel.len() > 0 {
        let range = Uniform::from(0..sel.len());
        let mut rng = rand::thread_rng();
        let v = range.sample( & mut rng );
        sel[v]
    } else {
        None
    }
}

pub fn navigate( log: & mut log::Log, constants: &constants::Constants, map_dropoffs: &mapraw::DropoffMap, map_units: & mut mapraw::UnitMap, map_resource: &mapraw::ResourceMap, map_field: &field::Field, resource_assign: & mut task::ResourceAssign ) -> Vec<(i32,Dir)> {

    let mut execute = vec![];
    let mut done : HashSet< i32> = HashSet::new();

    let mut queue = vec![];
    
    for i in resource_assign.stat.iter_mut() {
        match i.1.task {
            task::Task::Collect(pos,turns) => {
                let shipid = i.0;
                queue.push( *shipid );
                match turns {
                    None => {
                        let shipid = i.0;
                        queue.push( *shipid );
                    },
                    Some(t) => {
                        if t == 0 {
                            // i.1.task = task::Task::Collect(pos,None);
                            i.1.task = task::Task::Idle;
                            // let shipid = i.0;
                            // queue.push( *shipid );
                        } else {
                            i.1.task = task::Task::Collect(pos,Some(t-1))
                        }
                    }
                }
            },
            task::Task::Deposit(..) => {
                let shipid = i.0;
                queue.push( *shipid );
            },
            task::Task::EndGame(..) => {
                let shipid = i.0;
                queue.push( *shipid );
            },
            _ => {},
        }
    }

    while queue.len() > 0 {
        let shipid = queue.pop().unwrap();
        if !done.contains( &shipid ) {
            done.insert(shipid);
            match resource_assign.stat.get_mut(&shipid).unwrap().task {
                task::Task::Collect(x,_) | task::Task::Deposit(x) => {
                    let dest = x;
                    let pos = resource_assign.stat.get(&shipid).unwrap().pos;
                    let pos_new = get_feasible_route( log, &map_units, resource_assign, & mut done, pos, dest );
                    // //evaluate if it is worth moving to next cell
                    // constants.move_cost_ratio;
                    // map_resource.get() constants.extract_ratio;
                    
                    match pos_new {
                        Some(pp) => {

                            let is_dropoff = match map_dropoffs.get( pos.0, pos.1 ) {
                                Some(p) => {
                                    true
                                },
                                _ => { false },
                            };

                            let range = Uniform::from(0..100);
                            let mut rng = rand::thread_rng();
                            let v = range.sample( & mut rng );
                                
                            let resource_current = map_resource.get( pos.0, pos.1 );
                            let cost_move = (constants.move_cost_ratio as f32 * 0.01 * resource_current as f32) as i32;

                            let carry_halite = resource_assign.stat.get(&shipid).unwrap().halite;
                            if cost_move < (0.1 * carry_halite as f32) as i32 || is_dropoff || resource_current <= 50 || carry_halite >= 975 || v >= 90 {
                            
                                let unit_cur = map_units.get( pos.0, pos.1 );
                                map_units.remove( pos.0, pos.1 );
                                map_units.set( pp.0, pp.1, unit_cur );

                                log.log(&format!("navigating unit [{}][{}] -> [{}][{}]", pos.0, pos.1, pp.0, pp.1 ));

                                if pp.0 - pos.0 > 0 {
                                    execute.push( (shipid, Dir::YPos) );
                                } else if pp.0 - pos.0 < 0 {
                                    execute.push( (shipid, Dir::YNeg) );
                                }
                                else {
                                    if pp.1 - pos.1 > 0 {
                                        execute.push( (shipid, Dir::XPos) );
                                    }else if pp.1 - pos.1 < 0 {
                                        execute.push( (shipid, Dir::XNeg) );
                                    }
                                }
                            } else {
                                // resource_assign.stat.get_mut(&shipid).unwrap().task = task::Task::Idle;
                            }
                        },
                        _ => {
                            // resource_assign.stat.get_mut(&shipid).unwrap().task = task::Task::Idle;
                        },
                    }
                },
                _ => {},
            }
        }
    }
    execute
}

pub fn get_closest_dir( start: i32, end: i32, dim: i32 ) -> i32 {
    if end >= start {
        let d0 = end - start;
        let d1 = end-dim-start;
        if d0.abs() <= d1.abs() {
            d0
        }else {
            d1
        }
    } else {
        let d0 = end - start;
        let d1 = end+dim-start;
        if d0.abs() <= d1.abs() {
            d0
        }else {
            d1
        }
    }
}

