use std::collections::{HashMap};
use mapping::mapraw;
use std::cmp;

pub struct Field {
    pub f: Vec<Vec<f32>>,
    pub aux: Vec<Vec<i32>>, //containing satellite data
    pub dim: (i32,i32),
}

impl Field {
    pub fn maximum(&self) -> (i32,i32) {
        let mut max = None;
        let mut pos = None;
        for i in self.f.iter().enumerate() {
            for j in i.1.iter().enumerate() {
                match max {
                    None => { max = Some(*j.1); },
                    Some(x) => {
                        if *j.1 > x {
                            max = Some(*j.1);
                            pos = Some((i.0 as i32,j.0 as i32));
                        }
                    },
                }
            }
        }
        pos.unwrap()
    }
}

pub enum Filter {
    Square(usize),
    Circle(usize),
}

fn convolve<'a>( rm: &'a mapraw::ResourceMap, kernel: &Filter, y: i32, x: i32 ) -> usize {
    
    match kernel {
        &Filter::Square(length) => {
            let mut sum = 0usize;
            for cy in (y-length as i32)..=(y+length as i32) {
                for cx in (x-length as i32)..=(x+length as i32) {
                    sum += rm.get(cy,cx);
                }
            }
            sum as usize
        },
        _ => {
            unimplemented!();
        },
    }
}
    
impl<'a> From<(&'a mapraw::ResourceMap, Filter)> for Field {
    fn from( rm_filt: (&'a mapraw::ResourceMap,Filter) ) -> Self {
        let mut f = vec![ vec![0f32; rm_filt.0.dim.1 as usize]; rm_filt.0.dim.0 as usize];
        for y in 0..rm_filt.0.dim.0 {
            for x in 0..rm_filt.0.dim.1 {
                let val = convolve( rm_filt.0, &rm_filt.1, y, x );
                f[y as usize][x as usize ] = val as f32;
            }
        }
        Field {
            f: f,
            dim: rm_filt.0.dim,
            aux: vec![],
        }
    }
}

impl<'a> From<(&'a mapraw::DropoffMap,usize)> for Field {
    fn from( dm: (&'a mapraw::DropoffMap,usize) ) -> Self {
        let map = dm.0;
        let dim = cmp::min(map.dim.0, map.dim.1);
        let player_id = dm.1;
        let temp = HashMap::new();
        let dropoffs = match map.invmap.get(&player_id) {
            Some(x) => {
                x
            },
            _ => { &temp },
        };
        let mut f = vec![ vec![0f32; map.dim.1 as usize]; map.dim.0 as usize];
        let mut f_aux = vec![ vec![-99i32; map.dim.1 as usize]; map.dim.0 as usize];
        for i in dropoffs.iter() {
            let y = (i.1).0;
            let x = (i.1).1;
            for j in 0..map.dim.0 {
                let y_loc = (y+j) % map.dim.0;
                let dif_y = ( ((y_loc-y) % map.dim.0) + map.dim.0 ) % map.dim.0;
                for k in 0..map.dim.1 {
                    let x_loc = (x+k) % map.dim.1;
                    let dif_x = ( ((x_loc-x) % map.dim.1) + map.dim.1 ) % map.dim.1;
                    let norm_l1 = dif_y.abs() + dif_x.abs();
                    let mass = (-0.005 * norm_l1 as f32).exp();
                    if mass > f[y_loc as usize][x_loc as usize] {
                        f[y_loc as usize][x_loc as usize] = mass;
                        // f[y_loc as usize][x_loc as usize] = 1.;
                        f_aux[y_loc as usize][x_loc as usize] = *i.0;
                    }
                }
            }
        }
        Field {
            f: f,
            dim: map.dim,
            aux: f_aux,
        }
    }
}

pub fn point_mult( fa: &Field, fb: &Field ) -> Field {
    let mut f = vec![ vec![0f32; fa.dim.1 as usize]; fa.dim.0 as usize];
    for i in 0..fa.dim.0 as usize{
        for k in 0..fa.dim.1  as usize{
            f[i][k] = fa.f[i][k] * fb.f[i][k];
        }
    }
    Field {
        f: f,
        dim: fa.dim,
        aux: vec![],
    }
}

pub fn load_aux_field( f_dest: & mut Field, f_source: &Field ) {
    f_dest.aux = f_source.aux.clone();
}


//compute a distribution field near a given point on map based on l1 norm
impl<'a> From<(&'a Field,(i32,i32))> for Field {
    fn from( dm: (&'a Field,(i32,i32)) ) -> Self {
        let map = dm.0;
        let dim = cmp::min(map.dim.0, map.dim.1);
        let mut f = vec![ vec![0f32; map.dim.1 as usize]; map.dim.0 as usize];
        let y = (dm.1).0; //position of unit
        let x = (dm.1).1;
        for j in 0..map.dim.0 {
            let y_loc = (y+j) % map.dim.0;
            let dif_y = ( ((y_loc-y) % map.dim.0) + map.dim.0 ) % map.dim.0;
            for k in 0..map.dim.1 {
                let x_loc = (x+k) % map.dim.1;
                let dif_x = ( ((x_loc-x) % map.dim.1) + map.dim.1 ) % map.dim.1;
                let norm_l1 = dif_y.abs() + dif_x.abs();
                let mass = (-0.001 * norm_l1 as f32).exp();
                f[y_loc as usize][x_loc as usize] = mass;
            }
        }

        Field {
            f: f,
            dim: map.dim,
            aux: vec![],
        }
    }
}
