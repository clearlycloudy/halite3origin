use std::collections::{HashMap,HashSet};

use mapping::{field,mapraw};
use hlt::{constants,log};
use metric::norm;

#[derive(Clone,Copy)]
pub enum Task {
    Collect( (i32,i32), Option<i32> ), //location(y,x) to collect, radius
    Deposit( (i32,i32) ), //location to deposit
    RandomWalk(i32), //radius, TODO
    Idle,
    Dead,
    EndGame( (i32,i32) ),
}

impl Default for Task {
    fn default() -> Task {
        Task::Idle
    }
}

#[derive(Default,Clone,Copy)]
pub struct UnitStat {
    pub task: Task,
    pub halite: usize,
    pub avg_collection_rate: f32,
    pub trips: usize,
    pub pos: (i32,i32), //y,x
}

#[derive(Default,Clone)]
pub struct ResourceAssign {
    pub stat: HashMap< i32, UnitStat > //ship id -> ship stat
}

impl ResourceAssign {
    pub fn assign( & mut self, log: & mut log::Log, num_turn: usize, game_consts: &constants::Constants, f: &field::Field/*resource field point multiplied with dropoff field and loaded with dropoff aux data*/, map_resource: & mapraw::ResourceMap, map_unit: & mut mapraw::UnitMap, map_dropoff: &mapraw::DropoffMap, playerid: usize ) {

        let mut new_stat = HashMap::new();
        
        //update unit information from game engine
        if !map_unit.invmap.contains_key(&playerid) {
            map_unit.invmap.insert(playerid, HashMap::new());
        }

        // //detect dead units
        // let mut units = HashSet::new();
        // for i in map_unit.invmap.get(&playerid).unwrap().iter() {
        //     units.insert(*i.0 as i32);
        // }
        // let mut units_prev = HashSet::new();
        // for i in self.stat.iter() {
        //     units_prev.insert( *i.0 as i32 );
        // }
        // for i in units_prev.difference(&units) {
        //     self.stat.get_mut(i).unwrap().task = Task::Dead; //todo something possibly
        //     self.stat.remove(i); //remove dead units
        // }
        
        for i in map_unit.invmap.get(&playerid).unwrap().iter() {
            let unit_id = *i.0 as i32;
            let pos = i.1;
            match self.stat.get(&unit_id) {
                Some(x) => {
                    let mut stat = x.clone();
                    match map_unit.get( pos.0, pos.1 ) {
                        mapraw::Unit::Ship { player, id, halite } => {
                            if player == playerid && id as i32 == unit_id {
                                stat.halite = halite;
                                stat.pos = *pos;
                                new_stat.insert( id as i32, stat );
                            }
                        },
                        _ => {},
                    }
                },
                _ => {
                    match map_unit.get( pos.0, pos.1 ) {
                        mapraw::Unit::Ship { player, id, halite } => {
                            let mut st = UnitStat::default();
                            st.halite = halite;
                            st.pos = *pos;
                            st.task = Task::Idle;
                            new_stat.insert( id as i32, st );
                        },
                        _ => {},
                    }
                },
            }
        }

        self.stat = new_stat;

        // log.log(&format!("number of units: {}", map_unit.invmap.get(&playerid).unwrap().len() ));
        //update pos and halite
        for i in map_unit.invmap.get(&playerid).unwrap().iter(){
            let id = i.0;
            let pos = i.1;
            let unit = map_unit.get( pos.0, pos.1 );
            match unit {
                mapraw::Unit::Ship{ player, id, halite } => {
                    let id2 = id as i32;
                    let found = match self.stat.get_mut(&id2){
                        Some(x) => {
                            //existing unit
                            x.pos = *pos;
                            x.halite = halite;
                            true
                        },
                        None => {
                            false
                        }
                    };
                    if !found {
                        //newly craeted unit
                        log.log(&format!("detected new unit"));
                        let unit_stat = UnitStat {
                            task: Task::Idle,
                            halite: halite,
                            avg_collection_rate: 0f32,
                            trips: 0usize,
                            pos: *pos,
                        };
                        self.stat.insert( id as i32, unit_stat );
                    }
                },
                _ => {},
            }
        }

        //detect units done depositing
        for i in self.stat.iter_mut() {
            match map_dropoff.get( i.1.pos.0, i.1.pos.1 ) {
                Some(x) if x.0 == playerid => {
                    match i.1.task {
                        Task::Deposit( _ ) => {
                            i.1.task = Task::Idle;
                        },
                        _ => {},
                    }
                },
                _ => {},
            }
        }
        
        let max_halite = game_consts.max_halite;
        let max_turns = game_consts.max_turns;
        
        //detect end game condition for unit
        for i in self.stat.iter_mut() {
            let shipid = i.0;
            let shippos = i.1.pos;
            let dropoff_id = f.aux[shippos.0 as usize][shippos.1 as usize];
            let dropoff_pos = map_dropoff.invmap.get(&playerid).unwrap().get(&dropoff_id).unwrap();
            let dist = norm::norm_l1(dropoff_pos.0,dropoff_pos.1);
            // if num_turn as i32 + dist + 7 >= max_turns as i32 {
            //     i.1.task = Task::Deposit( *dropoff_pos );
            // }
        }
        
        //select units for collecting halite
        for i in self.stat.iter_mut() {
            match i.1.task {
                Task::Idle => {
                    //best best location to go from resource field and unit distance field
                    let unit_distance_field = field::Field::from( (f, (i.1.pos)) );
                    let unit_field = field::point_mult( &f, &unit_distance_field );
                    let target_pos = unit_field.maximum();
                    i.1.task = Task::Collect( target_pos, None );
                    log.log(&format!("assign unit {} to collect at [{}][{}]", i.0, target_pos.0, target_pos.1));
                },
                Task::Collect(x,_) => {
                    log.log(&format!("unit id: {}, halite: {}", i.0, i.1.halite));
                    if i.1.halite as f32 >= 0.9 * max_halite as f32 {
                        let shipid = i.0;
                        let shippos = i.1.pos;
                        let dropoff_id = f.aux[shippos.0 as usize][shippos.1 as usize];
                        let dropoff_pos = map_dropoff.invmap.get(&playerid).unwrap().get(&dropoff_id).unwrap();
                        i.1.task = Task::Deposit( *dropoff_pos );
                        log.log(&format!("assign unit {} to deposit at [{}][{}]", i.0, dropoff_pos.0, dropoff_pos.1));
                    }
                }
                _ => {},
            }
        }
    }
}
