extern crate rand;

mod hlt;
mod mapping;
mod policy;
mod metric;

use rand::Rng;
use rand::distributions::{Distribution,Uniform};
use rand::SeedableRng;
use rand::XorShiftRng;
use std::env;
use std::time::SystemTime;
use std::time::UNIX_EPOCH;
use std::time::{Duration,Instant};
use std::rc::Rc;
use std::cell::RefCell;
use std::ops::DerefMut;

fn main() {
    let args: Vec<String> = env::args().collect();
    let rng_seed: u64 = if args.len() > 1 {
        args[1].parse().unwrap()
    } else {
        SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs()
    };
    let seed_bytes: Vec<u8> = (0..16).map(|x| ((rng_seed >> (x % 8)) & 0xFF) as u8).collect();
    let mut rng: XorShiftRng = SeedableRng::from_seed([
        seed_bytes[0], seed_bytes[1], seed_bytes[2], seed_bytes[3],
        seed_bytes[4], seed_bytes[5], seed_bytes[6], seed_bytes[7],
        seed_bytes[8], seed_bytes[9], seed_bytes[10], seed_bytes[11],
        seed_bytes[12], seed_bytes[13], seed_bytes[14], seed_bytes[15]
    ]);

    let mut log = Rc::new(RefCell::new(hlt::log::Log::new()));
    let mut input = hlt::input::Input::new(&log);

    //inputs:
    //
    //constants
    //number of players
    //my id
    //for each player:
    //  player id, shipyard x, shipyard y
    //map width, map height
    //resource map of halite:
    //  [0][0] [0][1]... (1st row)
    //  [1][0] [1][1]...
    //  ...
        
    let constants = hlt::constants::Constants::new(log.borrow_mut().deref_mut(), &input.read_and_return_line());
    input.read_and_parse_line();
    let num_players : usize = input.next();
    let my_id : usize = input.next();
    let mut players = vec![];
    for _ in 0..num_players {
        input.read_and_parse_line();
        let my_id : usize = input.next();
        let shipyard_x : i32 = input.next();
        let shipyard_y : i32 = input.next();
        players.push( (my_id, shipyard_y, shipyard_x ) );
    }
    log.borrow_mut().open(my_id);
    input.read_and_parse_line();    
    let map_w : i32 = input.next();
    let map_h : i32 = input.next();
    let mut rm;
    {
        let mut v = vec![ vec![ 0; map_w as usize]; map_h as usize];
        for i in 0..map_h as usize {
            input.read_and_parse_line();
            for j in 0..map_w as usize {
                let amount : usize = input.next();
                v[i][j] = amount;
            }
        }
        rm = mapping::mapraw::ResourceMap { map: v, dim: (map_h, map_w) };
    }

    log.borrow_mut().log(&format!("constants: {}", constants));
    log.borrow_mut().log(&format!("num players: {}", num_players));
    log.borrow_mut().log(&format!("my id: {}", my_id));
    log.borrow_mut().log(&format!("map width: {}", map_w));
    log.borrow_mut().log(&format!("map height: {}", map_h));

    log.borrow_mut().flush();
    println!("origin");

    log.borrow_mut().log(&format!("Successfully created bot! My Player ID is {}. Bot rng seed is {}.", my_id, rng_seed));

    // let filt_size = 2;
    let filt_size = 1;

    let mut resource_assign = policy::task::ResourceAssign::default();

    let mut my_halite = 0;
    loop {

        //input:
        //
        //turn num
        //for each player:
        //  player_id  num_ships num_dropoffs halite_amount
        //  ship_id1 coord_x coord_y halite_value
        //  ship_id2 coord_x coord_y halite_value
        //  ..
        //  (num_ships)
        //  dropoff_id1 coord_x coord_y
        //  dropoff_id2 coord_x coord_y
        //  ..
        //  (num_dropoffs)
        //
        //map_update_count
        //
        let t_start = Instant::now();

        let mut map_dropoff = mapping::mapraw::DropoffMap::from( (map_h,map_w) );
        let mut map_unit = mapping::mapraw::UnitMap::from( (map_h,map_w) );

        input.read_and_parse_line();
        let turn_num : usize = input.next();

        log.borrow_mut().log(&format!("turn {} -------------------------------------", turn_num ));
        
        for _ in 0..num_players {

            input.read_and_parse_line();
            let player_id : usize = input.next();
            let num_ships : usize = input.next();
            let num_dropoffs : usize = input.next();
            let player_halite : usize = input.next();
            if player_id == my_id {
                my_halite = player_halite;
            }

            if player_id == my_id {
                log.borrow_mut().log(&format!("playerid: {}, num ships: {}, num dropoffs: {}, halite: {}", player_id, num_ships, num_dropoffs, player_halite));
            }
            
            for _ in 0..num_ships {
                input.read_and_parse_line();
                let ship_id : usize = input.next();
                let x : i32 = input.next();
                let y : i32 = input.next();
                let ship_halite : usize = input.next();

                if player_id == my_id {
                    log.borrow_mut().log(&format!("ship id: {}, y: {}, x: {}", ship_id, y, x));
                }
                
                map_unit.set( y, x, mapping::mapraw::Unit::Ship{ player: player_id, id: ship_id, halite: ship_halite } );
            }

            for _ in 0..num_dropoffs {
                input.read_and_parse_line();
                let dropoff_id : usize = input.next();
                let x : i32 = input.next();
                let y : i32 = input.next();
                map_dropoff.set( dropoff_id as i32, y, x, mapping::mapraw::Player( player_id ) );
            }

            //also count shipyard as a dropoff point
            for i in players.iter() {
                let id = i.0;
                let y = i.1;
                let x = i.2;
                map_dropoff.set( -1i32, y, x, mapping::mapraw::Player( id ) );
            }
            
        }

        //compute distance field of dropoff points to locations on map
        let f_dropoff = mapping::field::Field::from( (&map_dropoff, my_id) );
        // for (idyi,i) in f_dropoff.f.iter().enumerate() {
        //     for (idxj,j) in i.iter().enumerate() {
        //         log.borrow_mut().log(&format!("field_dropoff[{},{}]: {}", idyi, idxj, j ));
        //     }
        // }
            
        input.read_and_parse_line();
        let map_update_count : usize = input.next();
        log.borrow_mut().log(&format!("resource update count: {}", map_update_count));        
        for _ in 0..map_update_count {
            input.read_and_parse_line();
            let x : usize = input.next();
            let y : usize = input.next();
            let halite_amount : usize = input.next();
            rm.map[y][x] = halite_amount;
            log.borrow_mut().log(&format!("resource update [{}][{}]: {}", y,x,halite_amount));
        }

        // for (idyi,i) in rm.map.iter().enumerate() {
        //     for (idxj,j) in i.iter().enumerate() {
        //         log.borrow_mut().log(&format!("resource[{},{}]: {}", idyi, idxj, j ));
        //     }
        // }

        //compute resource map gradient

        //neighbouring average on halite resource map
        let f = mapping::field::Field::from( (&rm, mapping::field::Filter::Square(filt_size) ) );

        // for (idyi,i) in f.f.iter().enumerate() {
        //     for (idxj,j) in i.iter().enumerate() {
        //         log.borrow_mut().log(&format!("field[{},{}]: {}", idyi, idxj, j ));
        //     }
        // }

        //point wise multiplication of dropoff point field and resource field
        let mut f1 = mapping::field::point_mult( &f_dropoff, &f );

        //save nearest dropoff point id for each location on map
        mapping::field::load_aux_field( & mut f1, &f_dropoff );

        for (idyi,i) in f1.f.iter().enumerate() {
            for (idxj,j) in i.iter().enumerate() {
                log.borrow_mut().log(&format!("resource field .* dropoff filt [{},{}]: {}", idyi, idxj, j ));
            }
        }
        // for (idyi,i) in f1.aux.iter().enumerate() {
        //     for (idxj,j) in i.iter().enumerate() {
        //         log.borrow_mut().log(&format!("resource field .* dropoff filt aux [{},{}]: {}", idyi, idxj, j ));
        //     }
        // }

        match map_unit.invmap.get(&my_id) {
            Some(h) => {
                for t in h.iter() {
                    let id = t.0;
                    let pos = t.1;
                    log.borrow_mut().log(&format!("ship {} pos: [{}][{}]", id, pos.0, pos.1 ));
                }
            },
            _ => {},
        }

        resource_assign.assign( & mut log.borrow_mut(), turn_num, &constants, &f1, &rm, & mut map_unit, &map_dropoff, my_id );

        let ship_movement = mapping::nav::navigate( & mut log.borrow_mut(), &constants, &map_dropoff, & mut map_unit, &rm, &f, & mut resource_assign );

        let mut command_queue: Vec<String> = vec![];

        for i in ship_movement {
            let shipid = i.0;
            match i.1 {
                mapping::nav::Dir::YPos => {
                    command_queue.push( format!("m {} s", shipid ) );
                },
                mapping::nav::Dir::YNeg => {
                    command_queue.push( format!("m {} n", shipid ) );
                },
                mapping::nav::Dir::XPos => {
                    command_queue.push( format!("m {} e", shipid ) );
                },
                mapping::nav::Dir::XNeg => {
                    command_queue.push( format!("m {} w", shipid ) );
                },
            }
        }

        if my_halite > constants.ship_cost &&
            (turn_num as f32) < (constants.max_turns as f32 * 0.8)
        {
            if resource_assign.stat.len() < 15 {
                command_queue.push( format!("g") );
            }//  else {
            //     let range = Uniform::from(0..100);
            //     let mut rng = rand::thread_rng();
            //     let v = range.sample( & mut rng );
            //     if v >= 50 {
            //         command_queue.push( format!("g") );                    
            //     }
            // }
        }
            
        let mut t_elapsed = t_start.elapsed();
        let t_elapsed_nanos = t_elapsed.subsec_nanos() as u64;
        let t_elapsed_ms = t_elapsed.as_secs() * 1000 + t_elapsed_nanos / 1000000;

        log.borrow_mut().log(&format!("turn {} elapsed time: {}", turn_num, t_elapsed_ms));

        for i in command_queue.drain(..) {
            log.borrow_mut().log(&format!("turn {}, command: {}", turn_num, i));
            print!("{} ", i);
        }
        println!();
    }
}
