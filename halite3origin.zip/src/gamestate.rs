struct GameState {
    const: Constants
}
