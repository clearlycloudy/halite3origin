pub fn norm_l1( a: i32, b: i32 ) -> i32 {
    a.abs() + b.abs()
}
